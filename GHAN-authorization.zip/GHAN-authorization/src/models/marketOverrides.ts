// use to override serum market to use specifc mint
export const MINT_TO_MARKET: { [key: string]: string } = {};
