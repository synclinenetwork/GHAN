# solana-escrow

an implementation of an escrow on solana using [this guide](https://paulx.dev/2021/01/14/programming-on-solana-an-introduction)